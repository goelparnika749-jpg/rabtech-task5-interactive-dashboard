import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

st.set_page_config(page_title="E-Commerce KPI Dashboard", page_icon="📊", layout="wide")

st.title("📊 E-Commerce Executive Dashboard")
st.caption("Rabtech Academy | Task 5 — Interactive Dashboard & KPI Visualizations")
st.info("Dataset notice: This project uses synthetic/demo data created for learning. It does not represent a real company or real customers.")

@st.cache_data
def load_data():
    path = Path(__file__).parent / "ecommerce_orders.csv"
    data = pd.read_csv(path, parse_dates=["order_date"])
    data["month"] = data["order_date"].dt.to_period("M").dt.to_timestamp()
    return data

df = load_data()

# Sidebar filters
st.sidebar.header("Dashboard Filters")
min_date = df["order_date"].min().date()
max_date = df["order_date"].max().date()
date_range = st.sidebar.date_input("Order date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    start_date, end_date = pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1])
else:
    start_date, end_date = pd.to_datetime(min_date), pd.to_datetime(max_date)

category_options = sorted(df["category"].dropna().unique())
selected_categories = st.sidebar.multiselect("Product category", category_options, default=category_options)
country_options = sorted(df["country"].dropna().unique())
selected_countries = st.sidebar.multiselect("Country", country_options, default=country_options)
segment_options = sorted(df["customer_segment"].dropna().unique())
selected_segments = st.sidebar.multiselect("Customer segment", segment_options, default=segment_options)
channel_options = sorted(df["acquisition_channel"].dropna().unique())
selected_channels = st.sidebar.multiselect("Acquisition channel", channel_options, default=channel_options)

filtered = df[
    (df["order_date"] >= start_date) &
    (df["order_date"] <= end_date + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)) &
    (df["category"].isin(selected_categories)) &
    (df["country"].isin(selected_countries)) &
    (df["customer_segment"].isin(selected_segments)) &
    (df["acquisition_channel"].isin(selected_channels))
].copy()

if filtered.empty:
    st.warning("No records match these filters. Please widen the date range or select more filter values.")
    st.stop()

# KPI definitions: CAC = mean acquisition cost across unique customers represented in filtered orders.
# Churn rate = share of unique customers marked churned among customers represented in filtered orders.
unique_customers = filtered.drop_duplicates("customer_id")
revenue = filtered["revenue"].sum()
orders_count = filtered["order_id"].nunique()
aov = revenue / orders_count if orders_count else 0
cac = unique_customers["acquisition_cost"].mean() if len(unique_customers) else 0
churn_rate = unique_customers["churned"].mean() * 100 if len(unique_customers) else 0
profit = filtered["profit"].sum()

k1,k2,k3,k4,k5 = st.columns(5)
k1.metric("Revenue", f"${revenue:,.0f}")
k2.metric("Average Order Value", f"${aov:,.2f}")
k3.metric("Avg. Acquisition Cost", f"${cac:,.2f}")
k4.metric("Customer Churn Rate", f"{churn_rate:.1f}%")
k5.metric("Total Profit", f"${profit:,.0f}")

st.caption(f"Filtered orders: {orders_count:,} | Unique customers in filtered orders: {unique_customers['customer_id'].nunique():,}")

# Trendline / area chart
st.subheader("Revenue & Profit Trend")
monthly = filtered.groupby("month", as_index=False).agg(revenue=("revenue","sum"), profit=("profit","sum"))
fig_trend = go.Figure()
fig_trend.add_trace(go.Scatter(x=monthly["month"], y=monthly["revenue"], mode="lines", name="Revenue", fill="tozeroy"))
fig_trend.add_trace(go.Scatter(x=monthly["month"], y=monthly["profit"], mode="lines", name="Profit"))
fig_trend.update_layout(height=380, xaxis_title="Month", yaxis_title="Amount ($)", hovermode="x unified", legend_title="Metric")
st.plotly_chart(fig_trend, use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("Revenue by Product Category")
    cat = filtered.groupby("category", as_index=False).agg(revenue=("revenue","sum"), profit=("profit","sum"))
    fig_cat = px.bar(cat.sort_values("revenue", ascending=True), x="revenue", y="category", orientation="h", color="profit",
                     color_continuous_scale="Blues", hover_data=["profit"], title="Revenue and Profit by Category")
    fig_cat.update_layout(height=380, xaxis_title="Revenue ($)", yaxis_title="")
    st.plotly_chart(fig_cat, use_container_width=True)
with right:
    st.subheader("Geographic Revenue Map")
    geo = filtered.groupby("country", as_index=False).agg(revenue=("revenue","sum"), orders=("order_id","nunique"))
    fig_map = px.choropleth(geo, locations="country", locationmode="country names", color="revenue",
                            hover_name="country", hover_data=["orders"], color_continuous_scale="Viridis",
                            title="Revenue by Country")
    fig_map.update_layout(height=380, margin=dict(l=0,r=0,t=45,b=0))
    st.plotly_chart(fig_map, use_container_width=True)

left2, right2 = st.columns(2)
with left2:
    st.subheader("Acquisition Channel Performance")
    channel = filtered.groupby("acquisition_channel", as_index=False).agg(
        revenue=("revenue","sum"),
        acquisition_cost=("acquisition_cost","mean"),
        customers=("customer_id","nunique")
    )
    fig_channel = px.bar(channel, x="acquisition_channel", y="revenue", color="acquisition_cost",
                         hover_data=["customers"], color_continuous_scale="Oranges", title="Revenue by Acquisition Channel")
    fig_channel.update_layout(height=360, xaxis_title="", yaxis_title="Revenue ($)")
    st.plotly_chart(fig_channel, use_container_width=True)
with right2:
    st.subheader("Customer Segment Mix")
    segment = filtered.groupby("customer_segment", as_index=False).agg(revenue=("revenue","sum"), customers=("customer_id","nunique"))
    fig_seg = px.pie(segment, names="customer_segment", values="revenue", hole=0.45,
                     hover_data=["customers"], title="Revenue Share by Segment")
    fig_seg.update_layout(height=360)
    st.plotly_chart(fig_seg, use_container_width=True)

st.subheader("Drill-down: Explore Orders")
drill_cols = ["order_date","order_id","customer_id","country","city","customer_segment","acquisition_channel","category","revenue","profit","discount"]
st.dataframe(filtered[drill_cols].sort_values("order_date", ascending=False), use_container_width=True, hide_index=True)
csv = filtered[drill_cols].to_csv(index=False).encode("utf-8")
st.download_button("Download filtered orders as CSV", data=csv, file_name="filtered_orders.csv", mime="text/csv")

with st.expander("KPI definitions and limitations"):
    st.markdown("""
    - **Revenue:** Sum of revenue in the filtered order records.
    - **Average Order Value (AOV):** Revenue divided by distinct orders.
    - **Average Acquisition Cost (CAC):** Mean acquisition cost for unique customers represented in filtered orders. This is a simplified demo metric.
    - **Churn Rate:** Percentage of unique represented customers whose synthetic customer record is marked churned. This is a demo cohort metric, not a standard period-based churn calculation.
    - **Profit:** Sum of the simulated profit column.

    **Limitations:** All data is synthetic. CAC and churn are simplified for educational demonstration and should be replaced with validated business definitions and real data for production use.
    """)
st.caption("Built with Streamlit, Pandas and Plotly | Rabtech Academy Task 5")
