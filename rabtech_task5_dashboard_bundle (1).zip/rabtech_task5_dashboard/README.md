# Rabtech Academy Task 5 — Interactive Dashboard & KPI Visualizations

## Project overview
Interactive e-commerce dashboard built with Streamlit, Pandas and Plotly.

## Important dataset note
The included CSV files are **synthetic/demo data** created for this learning project. They do not describe real customers or a real company.

## Dashboard features
- KPI cards: Revenue, Average Order Value (AOV), average customer acquisition cost (CAC), churn rate, total profit
- Interactive date, category, country, segment and acquisition-channel filters
- Monthly revenue and profit trend chart
- Category performance bar chart
- Geographic revenue choropleth map
- Acquisition channel and customer segment charts
- Filtered order drill-down table and CSV download

## Run locally
1. Install Python 3.10 or newer.
2. Extract this folder.
3. Open a terminal in this folder and run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

4. The app will open in your browser (usually at `http://localhost:8501`).

## Publish online
Upload `app.py`, `requirements.txt`, `ecommerce_orders.csv`, and this README to a public GitHub repository. Then open Streamlit Community Cloud, sign in with GitHub, choose **Create app**, select your repository and `app.py`, and deploy. The generated app URL can be submitted as the Streamlit proof link.

## KPI definitions
- Revenue = sum of revenue
- AOV = revenue / number of distinct orders
- Average acquisition cost = average CAC among unique customers present in the filtered orders
- Churn rate = percentage of unique customers in the filtered records marked churned
- Profit = sum of profit

CAC and churn are simplified demo definitions. Use a real business's validated metric definitions before making real operational decisions.
